import React from 'react';
import { X, Trash2, CreditCard } from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  discount?: number;
  deliveryTime?: string;
}

interface CheckoutModalProps {
  mode: 'grocery' | 'fashion';
  cartItems: (Product | undefined)[];
  totalAmount: number;
  onClose: () => void;
  onRemoveItem: (index: number) => void;
  onPayment: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ 
  mode, 
  cartItems, 
  totalAmount, 
  onClose, 
  onRemoveItem,
  onPayment
}) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-bold">Your Cart</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-4 max-h-[50vh] overflow-y-auto">
          {cartItems.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Your cart is empty</p>
            </div>
          ) : (
            <div className="space-y-4">
              {cartItems.map((item, index) => (
                item && (
                  <div key={`${item.id}-${index}`} className="flex items-center justify-between border-b border-gray-100 pb-4">
                    <div className="flex items-center">
                      <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded-md mr-4" />
                      <div>
                        <h3 className="font-medium text-sm">{item.name}</h3>
                        <p className={`text-sm ${mode === 'grocery' ? 'text-green-600' : 'text-black'} font-bold`}>
                          ₹{item.price}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => onRemoveItem(index)} 
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                )
              ))}
            </div>
          )}
        </div>
        
        <div className="p-4 border-t border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <span className="font-medium">Total Amount:</span>
            <span className={`font-bold text-lg ${mode === 'grocery' ? 'text-green-600' : 'text-black'}`}>
              ₹{totalAmount}
            </span>
          </div>
          
          <button 
            onClick={onPayment}
            disabled={cartItems.length === 0}
            className={`w-full py-3 rounded-lg flex items-center justify-center space-x-2 ${
              mode === 'grocery' 
                ? 'bg-green-500 hover:bg-green-600 disabled:bg-green-300' 
                : 'bg-black hover:bg-gray-800 disabled:bg-gray-400'
            } text-white transition-colors duration-200`}
          >
            <CreditCard size={20} />
            <span>Pay Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;