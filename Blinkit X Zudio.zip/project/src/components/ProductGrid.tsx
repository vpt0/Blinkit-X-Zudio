import React, { useState } from 'react';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  discount?: number;
  deliveryTime?: string;
}

interface ProductGridProps {
  products: Product[];
  mode: 'grocery' | 'fashion';
  addToCart: (productId: number) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, mode, addToCart }) => {
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null);

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mt-4">
      {products.map((product) => (
        <div 
          key={product.id} 
          className="product-card bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
          onMouseEnter={() => setHoveredProduct(product.id)}
          onMouseLeave={() => setHoveredProduct(null)}
        >
          <div className="relative h-40 md:h-48 overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-500 ease-in-out"
              style={{
                transform: hoveredProduct === product.id && mode === 'fashion' ? 'scale(1.1)' : 'scale(1)'
              }}
            />
            {product.discount && (
              <div className={`absolute top-2 left-2 ${mode === 'grocery' ? 'bg-green-500' : 'bg-black'} text-white text-xs px-2 py-1 rounded`}>
                {product.discount}% OFF
              </div>
            )}
          </div>
          
          <div className="p-3">
            <div className="flex justify-between items-start">
              <h3 className="text-sm font-medium line-clamp-2 h-10">{product.name}</h3>
              <span className={`text-sm font-bold ${mode === 'grocery' ? 'text-green-600' : 'text-black'}`}>
                ₹{product.price}
              </span>
            </div>
            
            {product.deliveryTime && mode === 'grocery' && (
              <div className="text-xs text-gray-500 mt-1">
                {product.deliveryTime} delivery
              </div>
            )}
            
            {mode === 'fashion' && (
              <div className="text-xs text-gray-500 mt-1">
                {product.category}
              </div>
            )}
            
            <button 
              onClick={() => addToCart(product.id)}
              className={`add-btn mt-2 w-full py-1.5 rounded text-white text-sm font-medium ${
                mode === 'grocery' ? 'bg-green-500 hover:bg-green-600' : 'bg-black hover:bg-gray-800'
              }`}
            >
              ADD
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductGrid;