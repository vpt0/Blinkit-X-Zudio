import React from 'react';

interface Category {
  id: number;
  name: string;
  icon: string;
}

interface CategoryBarProps {
  categories: Category[];
  mode: 'grocery' | 'fashion';
}

const CategoryBar: React.FC<CategoryBarProps> = ({ categories, mode }) => {
  return (
    <div className="py-4 overflow-x-auto">
      <div className="flex space-x-4 min-w-max">
        {categories.map((category) => (
          <div 
            key={category.id} 
            className="flex flex-col items-center cursor-pointer transition-all duration-300 hover:opacity-80"
          >
            <div 
              className={`w-16 h-16 rounded-full flex items-center justify-center mb-2 ${
                mode === 'grocery' ? 'bg-green-100' : 'bg-gray-200'
              }`}
            >
              <img 
                src={category.icon} 
                alt={category.name} 
                className="w-10 h-10 object-contain"
              />
            </div>
            <span className="text-xs text-center">{category.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryBar;