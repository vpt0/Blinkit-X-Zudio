import React, { useEffect, useState } from 'react';
import { CheckCircle, X } from 'lucide-react';
import Confetti from 'react-confetti';

interface PaymentSuccessModalProps {
  mode: 'grocery' | 'fashion';
  onClose: () => void;
}

const PaymentSuccessModal: React.FC<PaymentSuccessModalProps> = ({ mode, onClose }) => {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="p-4 flex justify-end">
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-8 text-center">
          <div className="success-checkmark mb-6">
            <div className="check-icon"></div>
          </div>
          
          <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
          <p className={`text-lg ${mode === 'grocery' ? 'text-green-600' : 'text-gray-800'} mb-6`}>
            {mode === 'grocery' 
              ? 'Your items will be delivered in 2 hours!' 
              : 'Your fashion items will be delivered in 24 hours!'}
          </p>
          
          <button 
            onClick={onClose}
            className={`px-6 py-2 rounded-lg ${
              mode === 'grocery' ? 'bg-green-500 hover:bg-green-600' : 'bg-black hover:bg-gray-800'
            } text-white transition-colors duration-200`}
          >
            Continue Shopping
          </button>
        </div>
      </div>
      
      <div className="confetti-container">
        <Confetti
          width={windowSize.width}
          height={windowSize.height}
          recycle={false}
          numberOfPieces={200}
          gravity={0.2}
        />
      </div>
    </div>
  );
};

export default PaymentSuccessModal;