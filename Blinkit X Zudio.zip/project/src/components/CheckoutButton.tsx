import React from 'react';
import { ShoppingBag, ShoppingCart } from 'lucide-react';

interface CheckoutButtonProps {
  mode: 'grocery' | 'fashion';
  cartCount: number;
  onClick: () => void;
}

const CheckoutButton: React.FC<CheckoutButtonProps> = ({ mode, cartCount, onClick }) => {
  return (
    <button 
      onClick={onClick}
      className={`checkout-button flex items-center justify-center space-x-2 px-4 py-3 rounded-full ${
        mode === 'grocery' ? 'bg-green-500 hover:bg-green-600' : 'bg-black hover:bg-gray-800'
      } text-white`}
    >
      {mode === 'grocery' ? (
        <ShoppingCart size={20} />
      ) : (
        <ShoppingBag size={20} />
      )}
      <span>Checkout ({cartCount})</span>
    </button>
  );
};

export default CheckoutButton;