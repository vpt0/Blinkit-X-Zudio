import React, { useState, useEffect } from 'react';
import { ShoppingBag, ShoppingCart, Search, MapPin, ChevronDown } from 'lucide-react';

interface HeaderProps {
  mode: 'grocery' | 'fashion';
  toggleMode: () => void;
  cartCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  mode, 
  toggleMode, 
  cartCount,
  searchQuery,
  setSearchQuery
}) => {
  const [showNotification, setShowNotification] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (cartCount > 0) {
      setShowNotification(true);
      const timer = setTimeout(() => {
        setShowNotification(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [cartCount]);

  return (
    <header className={`sticky top-0 z-10 bg-white shadow-sm transition-all duration-300 ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center">
            <div className="mr-4">
              {mode === 'grocery' ? (
                <div className="logo text-2xl font-bold">
                  <span className="logo-blinkit">blinkit</span>
                </div>
              ) : (
                <div className="logo text-2xl font-bold flex items-center">
                  <span className="logo-blinkit">blinkit</span>
                  <span className="logo-x">X</span>
                  <span className="logo-zudio">ZUDIO</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center text-gray-600 text-sm">
              <MapPin size={16} className="mr-1" />
              <span className="mr-1">Deliver to:</span>
              <span className="font-semibold">Home</span>
              <ChevronDown size={16} className="ml-1" />
            </div>
          </div>
          
          <div className="flex items-center">
            <label className="toggle-switch mx-4">
              <input 
                type="checkbox" 
                checked={mode === 'fashion'} 
                onChange={toggleMode}
              />
              <span className="toggle-slider">
                <span className="mode-label grocery-label">G</span>
                <span className="mode-label fashion-label">F</span>
              </span>
            </label>
            
            <div className="relative">
              {mode === 'grocery' ? (
                <ShoppingCart size={24} className="text-green-500" />
              ) : (
                <ShoppingBag size={24} className="text-black" />
              )}
              {cartCount > 0 && (
                <span className={`absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-xs text-white ${mode === 'grocery' ? 'bg-green-500' : 'bg-black'}`}>
                  {cartCount}
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="pb-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search for products..."
              className="w-full py-2 px-10 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>
      </div>
      
      {showNotification && (
        <div className={`cart-notification ${mode === 'grocery' ? 'bg-green-500' : 'bg-black'}`}>
          Item added to cart!
        </div>
      )}
    </header>
  );
};

export default Header;