export const groceryProducts = [
  {
    id: 1,
    name: "Fresh Organic Bananas (6 pcs)",
    price: 40,
    image: "https://images.unsplash.com/photo-1603833665858-e61d17a86224?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YmFuYW5hc3xlbnwwfHwwfHx8MA%3D%3D",
    category: "Fruits & Vegetables",
    discount: 10,
    deliveryTime: "10 min"
  },
  {
    id: 2,
    name: "Amul Butter (500g)",
    price: 245,
    image: "https://images.unsplash.com/photo-1589985270958-bf087b2d8ed7?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnV0dGVyfGVufDB8fDB8fHww",
    category: "Dairy & Breakfast",
    deliveryTime: "15 min"
  },
  {
    id: 3,
    name: "Lay's Classic Salted Chips (90g)",
    price: 30,
    image: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y2hpcHN8ZW58MHx8MHx8fDA%3D",
    category: "Snacks & Munchies",
    discount: 5,
    deliveryTime: "10 min"
  },
  {
    id: 4,
    name: "Coca-Cola (2L)",
    price: 95,
    image: "https://images.unsplash.com/photo-1554866585-cd94860890b7?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y29jYSUyMGNvbGF8ZW58MHx8MHx8fDA%3D",
    category: "Cold Drinks",
    deliveryTime: "15 min"
  },
  {
    id: 5,
    name: "Britannia Good Day Cookies (200g)",
    price: 40,
    image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Y29va2llc3xlbnwwfHwwfHx8MA%3D%3D",
    category: "Bakery & Biscuits",
    discount: 15,
    deliveryTime: "10 min"
  },
  {
    id: 6,
    name: "Maggi 2-Minute Noodles (Pack of 6)",
    price: 78,
    image: "https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bm9vZGxlc3xlbnwwfHwwfHx8MA%3D%3D",
    category: "Instant Foods",
    deliveryTime: "10 min"
  },
  {
    id: 7,
    name: "Surf Excel Detergent Powder (1kg)",
    price: 190,
    image: "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGV0ZXJnZW50fGVufDB8fDB8fHww",
    category: "Home Needs",
    discount: 20,
    deliveryTime: "20 min"
  },
  {
    id: 8,
    name: "Dove Soap (Pack of 3)",
    price: 135,
    image: "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c29hcHxlbnwwfHwwfHx8MA%3D%3D",
    category: "Personal Care",
    deliveryTime: "15 min"
  },
  {
    id: 9,
    name: "Fresh Red Apples (4 pcs)",
    price: 120,
    image: "https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YXBwbGV8ZW58MHx8MHx8fDA%3D",
    category: "Fruits & Vegetables",
    deliveryTime: "10 min"
  },
  {
    id: 10,
    name: "Amul Milk (1L)",
    price: 68,
    image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWlsa3xlbnwwfHwwfHx8MA%3D%3D",
    category: "Dairy & Breakfast",
    deliveryTime: "10 min"
  }
];

export const fashionProducts = [
  {
    id: 101,
    name: "Men's Basic Cotton T-Shirt",
    price: 299,
    image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8dCUyMHNoaXJ0fGVufDB8fDB8fHww",
    category: "Men's Wear",
    discount: 20
  },
  {
    id: 102,
    name: "Women's Casual Denim Jacket",
    price: 999,
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8ZGVuaW0lMjBqYWNrZXR8ZW58MHx8MHx8fDA%3D",
    category: "Women's Wear",
    discount: 15
  },
  {
    id: 103,
    name: "Kids' Cartoon Print T-Shirt",
    price: 249,
    image: "https://images.unsplash.com/photo-1519278409-1f56fdda7fe5?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8a2lkcyUyMHNoaXJ0fGVufDB8fDB8fHww",
    category: "Kids' Wear"
  },
  {
    id: 104,
    name: "Unisex Canvas Sneakers",
    price: 599,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c25lYWtlcnN8ZW58MHx8MHx8fDA%3D",
    category: "Footwear",
    discount: 10
  },
  {
    id: 105,
    name: "Minimalist Analog Watch",
    price: 799,
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2F0Y2h8ZW58MHx8MHx8fDA%3D",
    category: "Accessories"
  },
  {
    id: 106,
    name: "Women's Floral Summer Dress",
    price: 699,
    image: "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZmxvcmFsJTIwZHJlc3N8ZW58MHx8MHx8fDA%3D",
    category: "New Arrivals",
    discount: 25
  },
  {
    id: 107,
    name: "Women's Embroidered Kurti",
    price: 899,
    image: "https://images.unsplash.com/photo-1610189020382-668a904cb5b4?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8a3VydGl8ZW58MHx8MHx8fDA%3D",
    category: "Ethnic Wear"
  },
  {
    id: 108,
    name: "Men's Gym Track Pants",
    price: 499,
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dHJhY2slMjBwYW50c3xlbnwwfHwwfHx8MA%3D%3D",
    category: "Sports Wear",
    discount: 5
  },
  {
    id: 109,
    name: "Men's Slim Fit Formal Shirt",
    price: 799,
    image: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Zm9ybWFsJTIwc2hpcnR8ZW58MHx8MHx8fDA%3D",
    category: "Men's Wear"
  },
  {
    id: 110,
    name: "Women's High Waist Jeans",
    price: 899,
    image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8amVhbnN8ZW58MHx8MHx8fDA%3D",
    category: "Women's Wear",
    discount: 15
  }
];