import React, { useState, useEffect } from 'react';
import { ShoppingBag, ShoppingCart, Search, Home, Menu, User, Heart, MapPin, ChevronDown, X, CreditCard } from 'lucide-react';
import './App.css';
import Header from './components/Header';
import CategoryBar from './components/CategoryBar';
import ProductGrid from './components/ProductGrid';
import CheckoutButton from './components/CheckoutButton';
import CheckoutModal from './components/CheckoutModal';
import PaymentSuccessModal from './components/PaymentSuccessModal';
import { groceryCategories, fashionCategories } from './data/categories';
import { groceryProducts, fashionProducts } from './data/products';

function App() {
  const [mode, setMode] = useState<'grocery' | 'fashion'>('grocery');
  const [cartItems, setCartItems] = useState<number[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isPaymentSuccess, setIsPaymentSuccess] = useState(false);

  const toggleMode = () => {
    setMode(mode === 'grocery' ? 'fashion' : 'grocery');
  };

  const addToCart = (productId: number) => {
    setCartItems([...cartItems, productId]);
    
    // Create and animate the flying item
    const flyingItem = document.createElement('div');
    flyingItem.className = 'flying-item';
    document.body.appendChild(flyingItem);
    
    setTimeout(() => {
      flyingItem.style.transform = 'translate(calc(100vw - 80px), 20px) scale(0.1)';
      flyingItem.style.opacity = '0';
    }, 10);
    
    setTimeout(() => {
      document.body.removeChild(flyingItem);
    }, 1000);
  };

  const removeFromCart = (index: number) => {
    const newCartItems = [...cartItems];
    newCartItems.splice(index, 1);
    setCartItems(newCartItems);
  };

  const handleCheckout = () => {
    setIsCheckoutOpen(true);
  };

  const handleCloseCheckout = () => {
    setIsCheckoutOpen(false);
  };

  const handlePayment = () => {
    setIsCheckoutOpen(false);
    setIsPaymentSuccess(true);
    
    // Reset cart after successful payment
    setTimeout(() => {
      setCartItems([]);
    }, 500);
    
    // Close success modal after 4 seconds
    setTimeout(() => {
      setIsPaymentSuccess(false);
    }, 4000);
  };

  const categories = mode === 'grocery' ? groceryCategories : fashionCategories;
  const products = mode === 'grocery' ? groceryProducts : fashionProducts;
  
  // Filter products based on search query
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get cart items details
  const cartItemsDetails = cartItems.map(id => {
    const allProducts = [...groceryProducts, ...fashionProducts];
    return allProducts.find(product => product.id === id);
  }).filter(item => item !== undefined);

  // Calculate total amount
  const totalAmount = cartItemsDetails.reduce((total, item) => total + (item?.price || 0), 0);

  return (
    <div className={`min-h-screen ${mode === 'grocery' ? 'bg-gray-100' : 'bg-gray-50'}`}>
      <Header 
        mode={mode} 
        toggleMode={toggleMode} 
        cartCount={cartItems.length}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />
      <main className="container mx-auto px-4 pb-20">
        <CategoryBar categories={categories} mode={mode} />
        <ProductGrid 
          products={filteredProducts} 
          mode={mode} 
          addToCart={addToCart} 
        />
      </main>
      
      {cartItems.length > 0 && (
        <CheckoutButton 
          mode={mode} 
          cartCount={cartItems.length} 
          onClick={handleCheckout} 
        />
      )}
      
      {isCheckoutOpen && (
        <CheckoutModal 
          mode={mode}
          cartItems={cartItemsDetails}
          totalAmount={totalAmount}
          onClose={handleCloseCheckout}
          onRemoveItem={removeFromCart}
          onPayment={handlePayment}
        />
      )}
      
      {isPaymentSuccess && (
        <PaymentSuccessModal 
          mode={mode} 
          onClose={() => setIsPaymentSuccess(false)} 
        />
      )}
      
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-2">
        <div className="container mx-auto flex justify-around items-center">
          <div className="flex flex-col items-center text-gray-500">
            <Home size={20} />
            <span className="text-xs mt-1">Home</span>
          </div>
          <div className="flex flex-col items-center text-gray-500">
            <Menu size={20} />
            <span className="text-xs mt-1">Categories</span>
          </div>
          <div className="flex flex-col items-center text-gray-500">
            <Search size={20} />
            <span className="text-xs mt-1">Search</span>
          </div>
          <div className="flex flex-col items-center text-gray-500">
            <User size={20} />
            <span className="text-xs mt-1">Account</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;